# Vue-VoteFeed #

- - - -
  This is a simple exercise for learning Vue.js library features. This is a simple webapp built using HTML/CSS/JS and Vue.js CDN library.

## Built Using ##

* HTML/CSS/Javascript
* Vue.js CDN Library

## Example ##

![alt text](https://github.com/ppranitps20/Vue-VoteFeed/blob/master/example.png)